"""Combine IRONFIT's original GitHub ZIP with the Assignment 5 add-on."""
from pathlib import Path
import subprocess
import zipfile
import tempfile
import sys

HERE = Path(__file__).resolve().parent
if len(sys.argv) not in (2, 3):
    print('Usage: py build_full_project.py original_repo.zip [output.zip]')
    raise SystemExit(1)
original = Path(sys.argv[1]).expanduser().resolve()
output = Path(sys.argv[2]).expanduser().resolve() if len(sys.argv) == 3 else HERE.parent / 'IRONFIT_Assignment5_FULL_PROJECT.zip'
if not original.is_file():
    print('Original repository ZIP not found:', original)
    raise SystemExit(1)

with tempfile.TemporaryDirectory() as temp:
    temp = Path(temp)
    with zipfile.ZipFile(original) as archive:
        # Block unsafe ZIP paths
        for info in archive.infolist():
            target = (temp / info.filename).resolve()
            if not target.is_relative_to(temp.resolve()):
                raise ValueError('Unsafe path in ZIP: ' + info.filename)
        archive.extractall(temp)

    matches = [p.parent for p in temp.rglob('index.html') if (p.parent / 'css' / 'style.css').exists() and (p.parent / 'programs.html').exists()]
    if len(matches) != 1:
        raise ValueError('Expected one IRONFIT website folder; found ' + str(len(matches)))
    site = matches[0]
    subprocess.run([sys.executable, str(HERE/'install_assignment5.py'), str(site)], check=True)
    for html in ('index.html', 'programs.html', 'pricing.html', 'contact.html'):
        content = (site/html).read_text(encoding='utf-8')
        if content.count('a5-exercise') != 1:
            raise ValueError('Installation failed: ' + html)
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(site.rglob('*')):
            if path.is_file() and not path.name.endswith('.a4backup') and path.name != '.DS_Store':
                archive.write(path, Path('ironfit-fitness-club')/path.relative_to(site))
    print('Created full project:', output)
    print('Test it in a browser and capture real screenshots before final submission.')
