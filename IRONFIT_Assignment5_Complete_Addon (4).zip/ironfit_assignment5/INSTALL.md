# IRONFIT — Assignment 5 (complete add-on)

This package is a complete **Assignment 5 add-on**, not a replacement for the original Assignment 4 website. Preserve the original images and existing HTML/CSS/JS.

## Quick installation (recommended)

1. Download the original repository as ZIP from https://github.com/neqty/ironfit-fitness-club (Code -> Download ZIP).
2. Extract it; the folder must contain `index.html`, `programs.html`, `pricing.html`, `contact.html`, etc.
3. Extract this add-on ZIP.
4. Run `python install_assignment5.py /path/to/your/ironfit-fitness-club-main` from this add-on folder (Windows: `py install_assignment5.py "C:\\path\\to\\ironfit-fitness-club-main"`).
5. Open index.html, programs.html, pricing.html, contact.html and test the Assignment 5 features.
6. ZIP the **whole combined original folder** for LMS submission. Do not submit the add-on alone as the project ZIP.

The installer makes `*.a4backup` copies of modified HTML files and will not insert the features twice. It adds simple HTML sections and script tags while keeping all existing content.

## Responsibilities / defense practice

- Ablaykhan: `index.html`, `js/assignment5-home.js` — Read More, menu arrow navigation and DOM text change.
- Erasyl: `programs.html`, `js/assignment5-programs.js` — arrays, objects, forEach, switch, callback.
- Arsen: `pricing.html`, `contact.html`, `js/assignment5-pricing.js`, `js/assignment5-contact.js` — filter, small audio effect, CSS animation and two-step demo form.

All participants should review and test these features before describing their contributions. The assignment also reuses previous project functionality from Assignment 4.

## Publication

Push the **installed project** to the team GitHub repository and verify your Netlify site. This package does not automatically publish. The connected GitHub API refused a write (403), so no GitHub changes are claimed.

## Report

The accompanying report records the implementation plan and code examples. Insert real screenshots of the running browser (and update the deployment verification) after installation before submitting.

## One-command full project builder

If you only have the original GitHub ZIP, put it beside `build_full_project.py` and run:

```powershell
py build_full_project.py "ironfit-fitness-club-main.zip" "IRONFIT_Assignment5_FULL_PROJECT.zip"
```

The command extracts the original site, adds the Assignment 5 code, checks the four target HTML pages, and produces a ZIP containing the **entire** website. It excludes installer backups. It does not upload to GitHub or create screenshots.
