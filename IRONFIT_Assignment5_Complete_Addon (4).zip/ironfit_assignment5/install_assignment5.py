"""Apply basic Assignment 5 exercises to the original IRONFIT website."""
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parent
if len(sys.argv) != 2:
    print('Usage: python install_assignment5.py PATH_TO_ORIGINAL_SITE')
    sys.exit(1)
site = Path(sys.argv[1]).expanduser().resolve()
if not (site / 'index.html').is_file() or not (site / 'css/style.css').is_file():
    print('Error: choose the extracted original site folder (with index.html and css/style.css).')
    sys.exit(1)

sections = {
'index.html': '''<section class="container a5-exercise" aria-label="Assignment 5 interaction">
  <h2>Why choose IRONFIT?</h2>
  <p>We offer workouts for different fitness levels.</p>
  <p id="a5-more-text" hidden>Our trainers help beginners feel comfortable, learn proper technique and reach their goals.</p>
  <button id="a5-more-button" class="btn btn-success" type="button">Read more</button>
  <p class="mt-3">Keyboard tip: focus a menu link and use left or right arrow keys.</p>
</section>''',
'programs.html': '''<section class="container a5-exercise" aria-label="Program chooser">
  <h2>Find your training program</h2>
  <label for="a5-program-select">Choose a program</label>
  <select id="a5-program-select" class="form-select mb-3">
    <option value="">Select a program</option>
    <option>Strength</option><option>Cardio</option><option>Group Fitness</option>
  </select>
  <p id="a5-program-result" role="status">Choose a program.</p>
  <ul id="a5-program-list"></ul>
</section>''',
'pricing.html': '''<section class="container a5-exercise" aria-label="Price filter">
  <h2>Find an affordable plan</h2>
  <label for="a5-price-select">Maximum monthly price</label>
  <select id="a5-price-select" class="form-select mb-3">
    <option value="15000">15,000 ₸</option>
    <option value="25000">25,000 ₸</option>
    <option value="40000" selected>40,000 ₸</option>
  </select>
  <ul id="a5-price-list" aria-live="polite"></ul>
</section>''',
'contact.html': '''<section class="container a5-exercise" aria-label="Demo two step trial form">
  <h2>Try a free intro session</h2>
  <p>This is a local demo. No real request is sent.</p>
  <form id="a5-trial-form">
    <div class="a5-step"><label for="a5-trial-name">Your name</label><input id="a5-trial-name" type="text" autocomplete="name"></div>
    <div class="a5-step" hidden><label for="a5-trial-program">Training type</label>
      <select id="a5-trial-program"><option>Strength</option><option>Cardio</option><option>Group Fitness</option></select>
    </div>
    <div class="a5-actions">
      <button id="a5-back" type="button" class="btn btn-outline-success">Back</button>
      <button id="a5-next" type="button" class="btn btn-success">Next</button>
      <button id="a5-finish" type="submit" class="btn btn-success">Finish</button>
    </div>
    <p id="a5-trial-message" role="status" class="mt-3"></p>
  </form>
</section>'''
}
scripts = {
'index.html':'assignment5-home.js',
'programs.html':'assignment5-programs.js',
'pricing.html':'assignment5-pricing.js',
'contact.html':'assignment5-contact.js'
}
for folder in ('js', 'css'):
    (site / folder).mkdir(exist_ok=True)
for p in (ROOT/'js').glob('*.js'):
    shutil.copy2(p, site/'js'/p.name)
shutil.copy2(ROOT/'css'/'assignment5.css', site/'css'/'assignment5.css')
for filename, section in sections.items():
    path = site / filename
    if not path.is_file():
        print('Missing', filename)
        sys.exit(1)
    html = path.read_text(encoding='utf-8')
    if 'a5-exercise' in html:
        print('Already installed:', filename)
        continue
    if '</main>' not in html or '</head>' not in html or '</body>' not in html:
        print('Unexpected HTML structure:', filename)
        sys.exit(1)
    shutil.copy2(path, site/(filename+'.a4backup'))
    html = html.replace('</head>', '  <link rel="stylesheet" href="css/assignment5.css">\n</head>', 1)
    html = html.replace('</main>', section+'\n</main>', 1)
    html = html.replace('</body>', f'  <script src="js/{scripts[filename]}" defer></script>\n</body>', 1)
    path.write_text(html, encoding='utf-8')
    print('Updated:', filename)
print('Done. Test all four pages before submitting.')
